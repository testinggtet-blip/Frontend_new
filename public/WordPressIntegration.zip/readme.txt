=== LetsNotify Push ===
Contributors: letsnotify
Donate link: https://letsnotify.in
Tags: push notifications, web push, browser notifications, saas
Requires at least: 5.0
Tested up to: 6.6
Stable tag: 1.0.1
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Enable push notifications on your WordPress site using the LetsNotify SaaS platform.

== Description ==

LetsNotify Push makes it simple to add **browser push notifications** to your WordPress site without writing code.  
All you need is your LetsNotify account credentials.

**Features:**
* Easy setup — just add your Connection ID, API Key, and Secret Key
* Service Worker auto-installed in your site root
* No need to edit theme files or copy scripts manually
* Secure credentials storage using the WordPress Settings API

This plugin connects your WordPress site with your LetsNotify SaaS account to enable push notifications.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/letsnotify-push` directory, or install via WordPress dashboard.
2. Activate the plugin through the 'Plugins' screen.
3. Go to **Settings → LetsNotify Push** (or via the top-level menu) and enter your credentials:
   * Connection ID
   * API Key
   * Secret Key
4. Save settings — done! 🎉

== Screenshots ==

1. Settings page with LetsNotify branding and input fields for credentials.
2. Example of push notification setup in action.

== Frequently Asked Questions ==

= Do I need a LetsNotify account? =
Yes. This plugin connects your WordPress site to your LetsNotify SaaS account.

= Where can I find my API keys? =
Login to your LetsNotify dashboard → Settings → API Credentials.

= Will this slow down my website? =
No, all scripts are served via LetsNotify CDN and optimized for performance.

= Is SSL/HTTPS required? =
Yes, push notifications only work on secure (HTTPS) websites.

== Changelog ==

= 1.0.1 =
* Added brand styling to settings page
* Added LetsNotify icon to admin menu
* Improved UI with WordPress Settings API

= 1.0.0 =
* Initial release with push notification support

== Upgrade Notice ==

= 1.0.1 =
UI enhancements and branding improvements — please update!