<?php
/**
 * Plugin Name: LetsNotify Push
 * Plugin URI:  https://letsnotify.in
 * Description: Enable push notifications for your WordPress site using LetsNotify SaaS.
 * Version:     1.6
 * Author:      LetsNotify
 * Author URI:  https://letsnotify.in
 * License:     GPL2
 * Text Domain: letsnotify-push
 */

if (!defined('ABSPATH')) {
    exit;
}

// --------------------------------------------------
// Activation / Deactivation
// --------------------------------------------------
register_activation_hook(__FILE__, 'letsnotify_activate');
register_deactivation_hook(__FILE__, 'letsnotify_deactivate');

/**
 * Copy LetsNotifySW.js from plugin to site root on activation.
 * If copy fails, set a transient so we can show an admin notice.
 */
function letsnotify_activate() {
    $src  = plugin_dir_path(__FILE__) . 'LetsNotifySW.js';
    $dest = ABSPATH . 'LetsNotifySW.js';

    if (!file_exists($src)) {
        // Source missing — set transient so admin sees the error
        set_transient('letsnotify_sw_copy_failed', 'missing_source', 30);
        return;
    }

    $copied = @copy($src, $dest);
    if (!$copied) {
        set_transient('letsnotify_sw_copy_failed', 'copy_failed', 30);
    } else {
        delete_transient('letsnotify_sw_copy_failed');
    }
}

/**
 * Remove LetsNotifySW.js from site root on deactivation.
 */
function letsnotify_deactivate() {
    $sw_file = ABSPATH . 'LetsNotifySW.js';
    if (file_exists($sw_file)) {
        @unlink($sw_file);
    }
}

// --------------------------------------------------
// Admin: menu, settings, sanitization
// --------------------------------------------------
add_action('admin_menu', 'letsnotify_add_admin_menu');
add_action('admin_init', 'letsnotify_settings_init');
add_action('admin_notices', 'letsnotify_admin_notices');

function letsnotify_add_admin_menu() {
    $icon_url = plugin_dir_url(__FILE__) . 'letsNotify_icon.png';

    add_menu_page(
        __('LetsNotify Push Settings', 'letsnotify-push'),
        __('LetsNotify Push', 'letsnotify-push'),
        'manage_options',
        'letsnotifySettings',
        'letsnotify_options_page',
        $icon_url,
        65
    );

    // Also register as settings submenu (convenience)
    add_options_page(
        __('LetsNotify Push', 'letsnotify-push'),
        __('LetsNotify Push', 'letsnotify-push'),
        'manage_options',
        'letsnotifySettings',
        'letsnotify_options_page'
    );
}

function letsnotify_settings_init() {
    register_setting(
        'letsnotifySettings',
        'letsnotify_options',
        array(
            'sanitize_callback' => 'letsnotify_sanitize_options'
        )
    );

    add_settings_section(
        'letsnotify_section',
        __('LetsNotify Configuration', 'letsnotify-push'),
        function() {
            echo '<p>' . __('Enter your LetsNotify credentials to enable push notifications.', 'letsnotify-push') . '</p>';
        },
        'letsnotifySettings'
    );

    add_settings_field(
        'connection_id',
        __('Connection ID', 'letsnotify-push'),
        'letsnotify_connection_id_render',
        'letsnotifySettings',
        'letsnotify_section'
    );

    add_settings_field(
        'api_key',
        __('API Key', 'letsnotify-push'),
        'letsnotify_api_key_render',
        'letsnotifySettings',
        'letsnotify_section'
    );

    add_settings_field(
        'secret_key',
        __('Secret Key', 'letsnotify-push'),
        'letsnotify_secret_key_render',
        'letsnotifySettings',
        'letsnotify_section'
    );
}

function letsnotify_connection_id_render() {
    $options = get_option('letsnotify_options');
    ?>
    <input type='text' name='letsnotify_options[connection_id]' 
           value='<?php echo esc_attr($options['connection_id'] ?? ''); ?>' 
           class="regular-text" required>
    <?php
}

function letsnotify_api_key_render() {
    $options = get_option('letsnotify_options');
    ?>
    <input type='text' name='letsnotify_options[api_key]' 
           value='<?php echo esc_attr($options['api_key'] ?? ''); ?>' 
           class="regular-text" required>
    <?php
}

function letsnotify_secret_key_render() {
    $options = get_option('letsnotify_options');
    ?>
    <input type='password' name='letsnotify_options[secret_key]' 
           value='<?php echo esc_attr($options['secret_key'] ?? ''); ?>' 
           class="regular-text" required>
    <?php
}

/**
 * Sanitize options and add settings messages.
 */
function letsnotify_sanitize_options($input) {
    $new_input = array();

    if (!empty($input['connection_id'])) {
        $new_input['connection_id'] = sanitize_text_field($input['connection_id']);
    } else {
        add_settings_error('letsnotify_options', 'connection_missing', __('Connection ID is required.', 'letsnotify-push'), 'error');
    }

    if (!empty($input['api_key'])) {
        $new_input['api_key'] = sanitize_text_field($input['api_key']);
    } else {
        add_settings_error('letsnotify_options', 'apikey_missing', __('API Key is required.', 'letsnotify-push'), 'error');
    }

    if (!empty($input['secret_key'])) {
        $new_input['secret_key'] = sanitize_text_field($input['secret_key']);
    } else {
        add_settings_error('letsnotify_options', 'secret_missing', __('Secret Key is required.', 'letsnotify-push'), 'error');
    }

    // If there are no errors, add a success message
    $errors = get_settings_errors('letsnotify_options');
    if (empty($errors)) {
        add_settings_error('letsnotify_options', 'settings_updated', __('Settings saved successfully.', 'letsnotify-push'), 'updated');
    }

    return $new_input;
}

/**
 * Show admin notice if SW copy failed on activation.
 */
function letsnotify_admin_notices() {
    $notice = get_transient('letsnotify_sw_copy_failed');
    if ($notice) {
        if ($notice === 'missing_source') {
            printf('<div class="notice notice-error"><p>%s</p></div>',
                esc_html__('LetsNotify: source file LetsNotifySW.js is missing from the plugin folder. Please include LetsNotifySW.js in the plugin root.', 'letsnotify-push')
            );
        } else {
            printf('<div class="notice notice-error"><p>%s</p></div>',
                esc_html__('LetsNotify: failed to copy LetsNotifySW.js to site root. Check write permissions or copy the file manually to /LetsNotifySW.js', 'letsnotify-push')
            );
        }
        delete_transient('letsnotify_sw_copy_failed');
    }
}

/**
 * Settings page HTML
 */
function letsnotify_options_page() {
    $icon_url = plugin_dir_url(__FILE__) . 'letsNotify.png';
    ?>
    <div class="wrap letsnotify-settings">
        <h1>
            <img src="<?php echo esc_url($icon_url); ?>" alt="LetsNotify" style="height:40px; vertical-align:middle; margin-right:10px;">
            <?php esc_html_e('LetsNotify Push Settings', 'letsnotify-push'); ?>
        </h1>

        <?php settings_errors('letsnotify_options'); ?>

        <form action='options.php' method='post'>
            <?php
            settings_fields('letsnotifySettings');
            do_settings_sections('letsnotifySettings');
            submit_button(__('Save Settings', 'letsnotify-push'));
            ?>
        </form>
    </div>

    <style>
        .letsnotify-settings {
            background-color: #056a5a; /* full background with product color */
            padding: 20px;
            border-radius: 8px;
        }

        .letsnotify-settings h1 {
            color: #fff;
            margin: 0 0 20px;
            display: flex;
            align-items: center;
        }

        .letsnotify-settings h1 img {
            padding: 4px;
        }

        .letsnotify-settings form {
            background: #f9f9f9;
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 6px;
            max-width: 700px;
        }

        .letsnotify-settings th {
            color: #056a5a;
            font-weight: 600;
            padding-top: 15px;
        }

        .letsnotify-settings input[type="text"],
        .letsnotify-settings input[type="password"] {
            width: 100%;
            max-width: 400px;
        }

        .letsnotify-settings .button-primary {
            background-color: #056a5a;
            border-color: #056a5a;
            box-shadow: none;
            text-shadow: none;
        }

        .letsnotify-settings .button-primary:hover {
            background-color: #045148;
            border-color: #045148;
        }
    </style>
    <?php
}

// --------------------------------------------------
// Frontend script injection
// --------------------------------------------------
add_action('wp_footer', function() {
    $options = get_option('letsnotify_options');
    $connectionId = esc_js($options['connection_id'] ?? '');
    $apiKey       = esc_js($options['api_key'] ?? '');
    $secretKey    = esc_js($options['secret_key'] ?? '');

    if ($connectionId && $apiKey && $secretKey) {
        echo '<script type="text/javascript" src="https://cdn.letsnotify.in/index.js"></script>';
        echo "<script>
            (function(){
                if(!window.LetsNotifySDK) return;
                const sdk = new LetsNotifySDK();
                const pushSDK = sdk.pushSdk();
                pushSDK.init({
                    connectionId: '{$connectionId}',
                    serviceWorkerPath: '/LetsNotifySW.js',
                    apiKey: '{$apiKey}',
                    secretKey: '{$secretKey}'
                });
            })();
        </script>";
    }
});