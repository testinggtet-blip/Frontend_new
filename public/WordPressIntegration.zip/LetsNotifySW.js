// LetsNotify Service Worker Template
importScripts("https://cdn.letsnotify.in/ServiceWorker.js");
